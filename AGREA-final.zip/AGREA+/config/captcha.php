<?php
// Local arithmetic challenge. No external service or API key required.
function captcha_field(string $scope): string {
    $a=random_int(2,12); $b=random_int(1,9);
    $token=bin2hex(random_bytes(16));
    $_SESSION['captcha'][$scope]=['token'=>$token,'answer'=>(string)($a+$b),'expires'=>time()+300];
    return '<div class="captcha-box"><strong>Human verification</strong><small>Complete the challenge to continue.</small><label for="captcha-answer">What is '.$a.' + '.$b.'?</label><input id="captcha-answer" name="captcha_answer" inputmode="numeric" pattern="[0-9]+" autocomplete="off" required placeholder="Your answer"><input type="hidden" name="captcha_token" value="'.$token.'"></div>';
}
function captcha_verify(string $scope): bool {
    $challenge=$_SESSION['captcha'][$scope]??null; unset($_SESSION['captcha'][$scope]);
    $token=$_POST['captcha_token']??null; $answer=$_POST['captcha_answer']??null;
    return $challenge && is_string($token) && is_string($answer) && time() <= $challenge['expires'] && hash_equals($challenge['token'],$token) && hash_equals($challenge['answer'],trim($answer));
}

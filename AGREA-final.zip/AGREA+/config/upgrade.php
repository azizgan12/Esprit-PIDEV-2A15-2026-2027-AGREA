<?php
// Idempotent upgrade for existing XAMPP databases; no user data is dropped.
function agrea_upgrade(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $pdo->exec('CREATE TABLE IF NOT EXISTS agrea_setup (name VARCHAR(80) PRIMARY KEY) ENGINE=InnoDB');
    if ($pdo->query("SELECT COUNT(*) FROM agrea_setup WHERE name='community_v3'")->fetchColumn()) { $done=true; return; }
    $lock = $pdo->query("SELECT GET_LOCK('agrea_community_v3', 10)")->fetchColumn();
    if (!$lock) throw new RuntimeException('Database setup busy; refresh shortly.');
    try {
        if ($pdo->query("SELECT COUNT(*) FROM agrea_setup WHERE name='community_v3'")->fetchColumn()) { $done=true; return; }
        $pdo->exec("ALTER TABLE users MODIFY COLUMN role VARCHAR(20) NOT NULL DEFAULT 'farmer'");
        foreach (['2026_11_23_create_trees_table.sql','2026_11_24_create_community_tables.sql'] as $file) {
            $sql = file_get_contents(__DIR__.'/../database/migrations/'.$file);
            $sql = preg_replace('/^--.*$/m','',$sql);
            foreach (explode(';',$sql) as $statement) if (trim($statement)!=='') $pdo->exec($statement);
        }
        $columns = ['users'=>['address'=>'VARCHAR(255) NULL','cin'=>'CHAR(8) NULL'], 'posts'=>['video_mime'=>'VARCHAR(32) NULL','video_data'=>'MEDIUMBLOB NULL','pinned'=>'TINYINT(1) NOT NULL DEFAULT 0']];
        $check=$pdo->prepare('SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name=? AND column_name=?');
        foreach ($columns as $table=>$fields) foreach ($fields as $column=>$definition) {
            $check->execute([$table,$column]); if (!$check->fetchColumn()) $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
        }
        require_once __DIR__.'/demo.php';
        $pdo->beginTransaction();
        try { agrea_seed($pdo); $pdo->exec("INSERT INTO agrea_setup VALUES ('community_v3')"); $pdo->commit(); }
        catch (Throwable $e) { $pdo->rollBack(); throw $e; }
        $done=true;
    } finally { $pdo->query("SELECT RELEASE_LOCK('agrea_community_v3')"); }
}

<?php

class database
{
    private $host = "localhost";
    private $dbname = "agrea";
    private $username = "root";
    private $password = "";

    public function connect()
    {
        try {
            $pdo = new PDO(
                "mysql:host=$this->host;dbname=$this->dbname;charset=utf8mb4",
                $this->username,
                $this->password
            );

            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            require_once __DIR__.'/upgrade.php';
            agrea_upgrade($pdo);
            return $pdo;

        } catch (PDOException $e) {
            error_log($e->getMessage());
            http_response_code(500);
            die("Database setup failed. Check that MySQL is running, the agrea database has been imported, and the configured user has CREATE and ALTER permissions. See Apache error log for details.");
        }
    }
}
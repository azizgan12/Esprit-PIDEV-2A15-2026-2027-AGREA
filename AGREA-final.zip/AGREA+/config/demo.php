<?php
function agrea_seed(PDO $pdo): void {
    $q=$pdo->prepare('SELECT user_id FROM users WHERE mail=?');
    $insert=$pdo->prepare('INSERT INTO users(name,mail,password,role) VALUES(?,?,?,?)');
    $accounts=[];
    foreach ([['AGREA Field Notes (Demo)','field','expert'],['Olive Grove (Demo)','olive','farmer'],['Green Harvest (Demo)','harvest','farmer']] as [$name,$key,$role]) {
        $mail=$key.'@demo.agrea.invalid'; $q->execute([$mail]); $id=$q->fetchColumn();
        if (!$id) { $insert->execute([$name,$mail,password_hash(bin2hex(random_bytes(32)),PASSWORD_DEFAULT),$role]); $id=$pdo->lastInsertId(); }
        $accounts[$key]=$id;
    }
    $items=[
      ['field','general','Welcome to the AGREA community! Share your field notes, questions and seasonal discoveries. 🌱','growth.gif',1],
      ['olive','water','Drip irrigation keeps water close to the roots. Check your emitters and soil moisture regularly.','irrigation.mp4',0],
      ['harvest','advice','Compost corner: combine dry leaves and green materials, aerate regularly and keep the pile slightly moist.','compost.mp4',0],
      ['olive','question','How do you protect young olive trees during dry spells? Share what has worked on your farm.',null,0],
      ['harvest','market','Seasonal harvest exchange: what produce is available near your farm this week?',null,0],
      ['field','pests','Field tip: inspect the underside of leaves and document symptoms before choosing a treatment.',null,0]
    ];
    $find=$pdo->prepare('SELECT post_id FROM posts WHERE user_id=? AND content=?');
    $add=$pdo->prepare('INSERT INTO posts(user_id,category,content,video_mime,video_data,pinned) VALUES(?,?,?,?,?,?)');
    $comment=$pdo->prepare('INSERT INTO comments(post_id,user_id,content) VALUES(?,?,?)');
    foreach ($items as $i=>[$author,$category,$content,$file,$pin]) {
        $content='[Demo] '.$content; $find->execute([$accounts[$author],$content]); if ($find->fetchColumn()) continue;
        $add->execute([$accounts[$author],$category,$content,$file?(str_ends_with($file,'.gif')?'image/gif':'video/mp4'):null,$file?file_get_contents(__DIR__.'/../assets/demo/'.$file):null,$pin]);
        $id=$pdo->lastInsertId();
        if ($i===0) $comment->execute([$id,$accounts['olive'],'Happy to exchange ideas with other growers!']);
        if ($i===1) $comment->execute([$id,$accounts['harvest'],'Checking the filters regularly helps too.']);
        if ($i===3) $comment->execute([$id,$accounts['field'],'Mulching can help reduce moisture loss.']);
    }
}

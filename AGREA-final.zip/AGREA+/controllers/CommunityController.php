<?php

require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../models/Post.php";
require_once __DIR__ . "/../models/Comment.php";

class CommunityController
{
    public const CATEGORIES = [
        "general"  => "General",
        "question" => "Question",
        "advice"   => "Advice",
        "market"   => "Market",
        "pests"    => "Pests & diseases",
        "water"    => "Water & irrigation",
    ];

    private const POST_MAX = 2000;
    private const COMMENT_MAX = 1000;
    private const PER_PAGE = 10;

    private $pdo;

    public function __construct()
    {
        $database = new Database();
        $this->pdo = $database->connect();
    }

    /* ---------- helpers ---------- */

    private function requireLogin()
    {
        if (!isset($_SESSION["user_id"])) {
            header("Location: index.php?action=login");
            exit;
        }
    }

    private function requireAdmin()
    {
        if (!isset($_SESSION["user_id"]) || ($_SESSION["role"] ?? "") !== "admin") {
            header("Location: index.php?action=login");
            exit;
        }
    }

    private function isAdmin(): bool
    {
        return ($_SESSION["role"] ?? "") === "admin";
    }

    // Mutating actions are POST-only (the CSRF token is checked in index.php)
    private function requirePostMethod()
    {
        if ($_SERVER["REQUEST_METHOD"] !== "POST") {
            header("Location: index.php?action=community");
            exit;
        }
    }

    private function len(string $value): int
    {
        return function_exists("mb_strlen") ? mb_strlen($value, "UTF-8") : strlen($value);
    }

    private function flash(string $type, string $message): void
    {
        $_SESSION["community_flash"] = [$type, $message];
    }

    private function pullFlash(): ?array
    {
        $flash = $_SESSION["community_flash"] ?? null;
        unset($_SESSION["community_flash"]);
        return $flash;
    }

    private function tablesReady(): bool
    {
        try {
            $count = $this->pdo->query(
                "SELECT COUNT(*) FROM information_schema.tables
                 WHERE table_schema = DATABASE()
                   AND table_name IN ('posts', 'comments', 'post_likes')"
            )->fetchColumn();
            return (int)$count === 3;
        } catch (PDOException $e) {
            return false;
        }
    }

    // Go back to the feed, keeping the filter and page the user was on
    private function backToFeed(?int $postId = null, bool $openComments = false)
    {
        $category = $_POST["category_filter"] ?? "";
        $page = (int)($_POST["page"] ?? 1);

        $url = "index.php?action=community";
        if (isset(self::CATEGORIES[$category])) {
            $url .= "&category=" . urlencode($category);
        }
        if ($page > 1) {
            $url .= "&page=" . $page;
        }
        if ($postId && $openComments) {
            $url .= "&open=" . $postId;
        }
        if ($postId) {
            $url .= "#post-" . $postId;
        }
        header("Location: " . $url);
        exit;
    }

    private function backAfterDelete()
    {
        if (($_POST["from"] ?? "") === "admin" && $this->isAdmin()) {
            header("Location: index.php?action=adminCommunity");
            exit;
        }
        $this->backToFeed();
    }

    private function findPost(int $id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM posts WHERE post_id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    /* ---------- feed ---------- */

    public function community()
    {
        $this->requireLogin();

        $tablesReady = $this->tablesReady();
        $categories = self::CATEGORIES;
        $flash = $this->pullFlash();
        $posts = [];
        $commentsByPost = [];
        $category = "";
        $page = 1;
        $pages = 1;
        $total = 0;
        $openPost = (int)($_GET["open"] ?? 0);
        $currentUserId = (int)$_SESSION["user_id"];
        $isAdmin = $this->isAdmin();

        if ($tablesReady) {
            $category = $_GET["category"] ?? "";
            if (!isset($categories[$category])) {
                $category = "";
            }

            $where = "";
            $params = [];
            if ($category !== "") {
                $where = "WHERE p.category = ?";
                $params[] = $category;
            }

            $countStmt = $this->pdo->prepare("SELECT COUNT(*) FROM posts p $where");
            $countStmt->execute($params);
            $total = (int)$countStmt->fetchColumn();

            $pages = max(1, (int)ceil($total / self::PER_PAGE));
            $page = min(max(1, (int)($_GET["page"] ?? 1)), $pages);
            $offset = ($page - 1) * self::PER_PAGE;
            $limit = self::PER_PAGE;

            $sql = "SELECT p.post_id, p.user_id, p.category, p.content, p.pinned, p.video_mime, p.created_at, p.updated_at,
                           TIMESTAMPDIFF(SECOND, p.created_at, NOW()) AS age_seconds,
                           u.name, u.role, u.profile_picture,
                           (SELECT COUNT(*) FROM post_likes l WHERE l.post_id = p.post_id) AS like_count,
                           (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id) AS comment_count,
                           EXISTS(SELECT 1 FROM post_likes l2
                                  WHERE l2.post_id = p.post_id AND l2.user_id = ?) AS liked
                    FROM posts p
                    JOIN users u ON u.user_id = p.user_id
                    $where
                    ORDER BY p.pinned DESC, p.created_at DESC, p.post_id DESC
                    LIMIT $limit OFFSET $offset";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array_merge([$currentUserId], $params));
            $posts = $stmt->fetchAll();

            if ($posts) {
                $ids = array_map(static fn($p) => (int)$p["post_id"], $posts);
                $in = implode(",", array_fill(0, count($ids), "?"));
                $cStmt = $this->pdo->prepare(
                    "SELECT c.comment_id, c.post_id, c.user_id, c.content, c.created_at,
                            TIMESTAMPDIFF(SECOND, c.created_at, NOW()) AS age_seconds,
                            u.name, u.role, u.profile_picture
                     FROM comments c
                     JOIN users u ON u.user_id = c.user_id
                     WHERE c.post_id IN ($in)
                     ORDER BY c.created_at ASC, c.comment_id ASC"
                );
                $cStmt->execute($ids);
                foreach ($cStmt->fetchAll() as $comment) {
                    $commentsByPost[(int)$comment["post_id"]][] = $comment;
                }
            }
        }

        require __DIR__ . "/../views/community/index.php";
    }

    /* ---------- posts ---------- */

    public function createPost()
    {
        $this->requireLogin();
        $this->requirePostMethod();

        $content = trim($_POST["content"] ?? "");
        $category = $_POST["category"] ?? "general";

        if (!$this->tablesReady()) {
            $this->flash("error", "The community tables are missing. Apply the community migration first.");
        } elseif ($content === "") {
            $this->flash("error", "Write something before publishing.");
        } elseif ($this->len($content) > self::POST_MAX) {
            $this->flash("error", "A post can contain at most " . self::POST_MAX . " characters.");
        } elseif (!isset(self::CATEGORIES[$category])) {
            $this->flash("error", "Please choose a valid category.");
        } else {
            $file = $_FILES['video'] ?? null;
            $mime = null; $video = null;
            if ($file && $file['error'] !== UPLOAD_ERR_NO_FILE) {
                if ($file['error'] !== UPLOAD_ERR_OK || $file['size'] > 12 * 1024 * 1024) {
                    $this->flash('error', 'Media upload failed (maximum 12 MB).'); $this->backToFeed();
                }
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);
                if (!in_array($mime, ['video/mp4', 'video/webm', 'image/gif'], true)) {
                    $this->flash('error', 'Only MP4, WebM and GIF files are accepted.'); $this->backToFeed();
                }
                $video = file_get_contents($file['tmp_name']);
            }
            $post = new Post((int)$_SESSION["user_id"], $content, $category);
            $stmt = $this->pdo->prepare(
                "INSERT INTO posts (user_id, category, content, video_mime, video_data) VALUES (?, ?, ?, ?, ?)"
            );
            $stmt->execute([$post->getUserId(), $post->getCategory(), $post->getContent(), $mime, $video]);
            $this->flash("success", "Your post is published.");
        }

        header("Location: index.php?action=community");
        exit;
    }

    // Only the author can edit a post
    public function editPost()
    {
        $this->requireLogin();

        if (!$this->tablesReady()) {
            header("Location: index.php?action=community");
            exit;
        }

        $id = (int)($_GET["id"] ?? $_POST["post_id"] ?? 0);
        $post = $this->findPost($id);

        if (!$post || (int)$post["user_id"] !== (int)$_SESSION["user_id"]) {
            $this->flash("error", "You can only edit your own posts.");
            header("Location: index.php?action=community");
            exit;
        }

        $error = "";
        $categories = self::CATEGORIES;
        $postMax = self::POST_MAX;

        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $content = trim($_POST["content"] ?? "");
            $category = $_POST["category"] ?? "";

            if ($content === "") {
                $error = "A post cannot be empty.";
            } elseif ($this->len($content) > self::POST_MAX) {
                $error = "A post can contain at most " . self::POST_MAX . " characters.";
            } elseif (!isset(self::CATEGORIES[$category])) {
                $error = "Please choose a valid category.";
            } else {
                $stmt = $this->pdo->prepare(
                    "UPDATE posts SET content = ?, category = ?, updated_at = NOW()
                     WHERE post_id = ? AND user_id = ?"
                );
                $stmt->execute([$content, $category, $id, (int)$_SESSION["user_id"]]);
                $this->flash("success", "Your post was updated.");
                header("Location: index.php?action=community#post-" . $id);
                exit;
            }

            // Keep what the user typed when validation fails
            $post["content"] = $content;
            $post["category"] = $category;
        }

        require __DIR__ . "/../views/community/edit.php";
    }

    // Author or administrator
    public function deletePost()
    {
        $this->requireLogin();
        $this->requirePostMethod();

        $id = (int)($_POST["post_id"] ?? 0);
        $post = $this->findPost($id);

        if (!$post) {
            $this->flash("error", "This post no longer exists.");
        } elseif ((int)$post["user_id"] !== (int)$_SESSION["user_id"] && !$this->isAdmin()) {
            $this->flash("error", "You cannot delete this post.");
        } else {
            $this->pdo->prepare("DELETE FROM posts WHERE post_id = ?")->execute([$id]);
            $this->flash("success", "Post deleted.");
        }

        $this->backAfterDelete();
    }

    /* ---------- likes ---------- */

    public function toggleLike()
    {
        $this->requireLogin();
        $this->requirePostMethod();

        $postId = (int)($_POST["post_id"] ?? 0);
        $userId = (int)$_SESSION["user_id"];

        if (!$this->findPost($postId)) {
            $this->flash("error", "This post no longer exists.");
            $this->backToFeed();
        }

        $delete = $this->pdo->prepare("DELETE FROM post_likes WHERE post_id = ? AND user_id = ?");
        $delete->execute([$postId, $userId]);

        if ($delete->rowCount() === 0) {
            $this->pdo->prepare(
                "INSERT IGNORE INTO post_likes (post_id, user_id) VALUES (?, ?)"
            )->execute([$postId, $userId]);
        }

        $this->backToFeed($postId);
    }

    /* ---------- comments ---------- */

    public function addComment()
    {
        $this->requireLogin();
        $this->requirePostMethod();

        $postId = (int)($_POST["post_id"] ?? 0);
        $content = trim($_POST["content"] ?? "");

        if (!$this->findPost($postId)) {
            $this->flash("error", "This post no longer exists.");
            $this->backToFeed();
        }

        if ($content === "") {
            $this->flash("error", "A comment cannot be empty.");
        } elseif ($this->len($content) > self::COMMENT_MAX) {
            $this->flash("error", "A comment can contain at most " . self::COMMENT_MAX . " characters.");
        } else {
            $comment = new Comment($postId, (int)$_SESSION["user_id"], $content);
            $this->pdo->prepare(
                "INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)"
            )->execute([$comment->getPostId(), $comment->getUserId(), $comment->getContent()]);
        }

        $this->backToFeed($postId, true);
    }

    // Comment author, post author or administrator
    public function deleteComment()
    {
        $this->requireLogin();
        $this->requirePostMethod();

        $id = (int)($_POST["comment_id"] ?? 0);
        $stmt = $this->pdo->prepare(
            "SELECT c.comment_id, c.post_id, c.user_id, p.user_id AS post_owner
             FROM comments c JOIN posts p ON p.post_id = c.post_id
             WHERE c.comment_id = ?"
        );
        $stmt->execute([$id]);
        $comment = $stmt->fetch();

        $me = (int)$_SESSION["user_id"];
        $postId = null;

        if (!$comment) {
            $this->flash("error", "This comment no longer exists.");
        } elseif ((int)$comment["user_id"] !== $me && (int)$comment["post_owner"] !== $me && !$this->isAdmin()) {
            $this->flash("error", "You cannot delete this comment.");
        } else {
            $this->pdo->prepare("DELETE FROM comments WHERE comment_id = ?")->execute([$id]);
            $postId = (int)$comment["post_id"];
        }

        if (($_POST["from"] ?? "") === "admin" && $this->isAdmin()) {
            header("Location: index.php?action=adminCommunity");
            exit;
        }
        $this->backToFeed($postId, $postId !== null);
    }

    public function video(): void
    {
        $this->requireLogin();
        $stmt = $this->pdo->prepare('SELECT video_mime, video_data FROM posts WHERE post_id = ?');
        $stmt->execute([(int)($_GET['id'] ?? 0)]);
        $v = $stmt->fetch();
        if (!$v || !$v['video_data'] || !in_array($v['video_mime'], ['video/mp4','video/webm','image/gif'], true)) { http_response_code(404); return; }
        session_write_close();
        header('Content-Type: '.$v['video_mime']);
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, no-store');
        header('Content-Length: '.strlen($v['video_data']));
        echo $v['video_data'];
    }

    public function pinPost(): void
    {
        $this->requireAdmin(); $this->requirePostMethod();
        $this->pdo->prepare('UPDATE posts SET pinned = NOT pinned WHERE post_id = ?')->execute([(int)($_POST['post_id'] ?? 0)]);
        $this->flash('success', 'Featured status updated.');
        header('Location: index.php?action=adminCommunity'); exit;
    }

    /* ---------- administration ---------- */

    public function adminCommunity()
    {
        $this->requireAdmin();

        $tablesReady = $this->tablesReady();
        $flash = $this->pullFlash();
        $categories = self::CATEGORIES;
        $stats = ["posts" => 0, "comments" => 0, "likes" => 0, "authors" => 0];
        $posts = [];
        $comments = [];

        if ($tablesReady) {
            $stats = $this->pdo->query(
                "SELECT (SELECT COUNT(*) FROM posts) AS posts,
                        (SELECT COUNT(*) FROM comments) AS comments,
                        (SELECT COUNT(*) FROM post_likes) AS likes,
                        (SELECT COUNT(DISTINCT user_id) FROM posts) AS authors"
            )->fetch();

            $posts = $this->pdo->query(
                "SELECT p.post_id, p.category, p.content, p.pinned, p.video_mime, p.created_at, u.name,
                        (SELECT COUNT(*) FROM post_likes l WHERE l.post_id = p.post_id) AS like_count,
                        (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.post_id) AS comment_count
                 FROM posts p JOIN users u ON u.user_id = p.user_id
                 ORDER BY p.pinned DESC, p.created_at DESC, p.post_id DESC
                 LIMIT 100"
            )->fetchAll();

            $comments = $this->pdo->query(
                "SELECT c.comment_id, c.post_id, c.content, c.created_at, u.name
                 FROM comments c JOIN users u ON u.user_id = c.user_id
                 ORDER BY c.created_at DESC, c.comment_id DESC
                 LIMIT 50"
            )->fetchAll();
        }

        require __DIR__ . "/../views/backoffice/community_admin.php";
    }
}

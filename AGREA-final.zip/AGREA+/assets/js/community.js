/* AGREA Community — character counter and auto-growing textarea */
(function () {
    "use strict";
    document.querySelectorAll("textarea[data-counter]").forEach(function (area) {
        var out = document.getElementById(area.getAttribute("data-counter"));
        function update() {
            if (out) out.textContent = area.value.length;
            area.style.height = "auto";
            area.style.height = Math.min(area.scrollHeight, 360) + "px";
        }
        area.addEventListener("input", update);
        update();
    });
})();

// Local attachment preview; no network request until publishing.
const mediaInput = document.querySelector('input[name="video"]');
if (mediaInput) {
  let url;
  const preview = document.createElement('div');
  mediaInput.closest('label').after(preview);
  mediaInput.addEventListener('change', () => {
    if (url) URL.revokeObjectURL(url);
    preview.replaceChildren();
    const file = mediaInput.files[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) { mediaInput.value = ''; preview.textContent = 'Maximum attachment size: 12 MB.'; return; }
    if (!['image/gif','video/mp4','video/webm'].includes(file.type)) return;
    url = URL.createObjectURL(file);
    const element = document.createElement(file.type === 'image/gif' ? 'img' : 'video');
    element.className = 'media-preview'; element.src = url;
    if (element.tagName === 'VIDEO') { element.controls = true; element.preload = 'metadata'; }
    else element.alt = 'GIF preview';
    preview.append(element);
  });
}

<?php

class Comment
{
    private $comment_id;
    private $post_id;
    private $user_id;
    private $content;
    private $created_at;

    public function __construct($post_id = null, $user_id = null, $content = "", $comment_id = null)
    {
        $this->post_id = $post_id;
        $this->user_id = $user_id;
        $this->content = $content;
        $this->comment_id = $comment_id;
    }

    public function getCommentId() { return $this->comment_id; }
    public function getPostId() { return $this->post_id; }
    public function getUserId() { return $this->user_id; }
    public function getContent() { return $this->content; }
    public function getCreatedAt() { return $this->created_at; }

    public function setCommentId($comment_id) { $this->comment_id = $comment_id; }
    public function setPostId($post_id) { $this->post_id = $post_id; }
    public function setUserId($user_id) { $this->user_id = $user_id; }
    public function setContent($content) { $this->content = $content; }
    public function setCreatedAt($created_at) { $this->created_at = $created_at; }
}

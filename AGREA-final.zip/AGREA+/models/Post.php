<?php

class Post
{
    private $post_id;
    private $user_id;
    private $category;
    private $content;
    private $created_at;
    private $updated_at;

    public function __construct($user_id = null, $content = "", $category = "general", $post_id = null)
    {
        $this->user_id = $user_id;
        $this->content = $content;
        $this->category = $category;
        $this->post_id = $post_id;
    }

    public function getPostId() { return $this->post_id; }
    public function getUserId() { return $this->user_id; }
    public function getCategory() { return $this->category; }
    public function getContent() { return $this->content; }
    public function getCreatedAt() { return $this->created_at; }
    public function getUpdatedAt() { return $this->updated_at; }

    public function setPostId($post_id) { $this->post_id = $post_id; }
    public function setUserId($user_id) { $this->user_id = $user_id; }
    public function setCategory($category) { $this->category = $category; }
    public function setContent($content) { $this->content = $content; }
    public function setCreatedAt($created_at) { $this->created_at = $created_at; }
    public function setUpdatedAt($updated_at) { $this->updated_at = $updated_at; }
}

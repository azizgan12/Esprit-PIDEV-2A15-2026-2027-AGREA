<?php require_once __DIR__ . "/../shared/community_helpers.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Community - AGREA</title>
    <link rel="icon" href="assets/images/logo/AGREA.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php require __DIR__ . "/../shared/sidebar.php"; ?>
<main class="admin-container community-page">
    <section class="community-hero"><span>AGREA / FIELD NOTES</span><h1>Grow together.</h1><p>Ideas, harvests and knowledge from the people who cultivate tomorrow.</p><div class="hero-orbit" aria-hidden="true">✳</div></section><div class="dashboard-heading">
        <div>
            <h2>AGREA Community</h2>
            <p>Share advice, ask questions and talk with farmers, experts and suppliers.</p>
        </div>
        <span class="role-badge"><?= (int)$total ?> post<?= $total === 1 ? "" : "s" ?></span>
    </div>

    <?php if ($flash): ?>
        <div class="<?= $flash[0] === "success" ? "success" : "error" ?>" role="status"><?= cm_e($flash[1]) ?></div>
    <?php endif; ?>

    <?php if (!$tablesReady): ?>
        <div class="error" role="status">The community is almost ready. Apply <code>database/migrations/2026_11_24_create_community_tables.sql</code> to enable posts, comments and likes.</div>
    <?php else: ?>

    <form class="post-composer" enctype="multipart/form-data" method="post" action="index.php?action=createPost">
        <?= csrf_field() ?>
        <?= cm_avatar(["name" => $_SESSION["name"] ?? "?"], "avatar") ?>
        <div class="composer-body">
            <textarea name="content" rows="3" maxlength="2000" required data-counter="composer-count"
                      placeholder="What's happening on your farm, <?= cm_e(explode(" ", $_SESSION["name"] ?? "")[0]) ?>?"></textarea>
            <label class="video-picker">＋ Add video or GIF (MP4 / WebM / GIF, max 12 MB)<input type="file" name="video" accept="video/mp4,video/webm,image/gif"></label><div class="composer-bar">
                <select name="category" aria-label="Category">
                    <?php foreach ($categories as $key => $label): ?>
                        <option value="<?= cm_e($key) ?>"><?= cm_e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="char-count"><span id="composer-count">0</span>/2000</span>
                <button class="primary-action" type="submit">Publish</button>
            </div>
        </div>
    </form>

    <nav class="category-filter" aria-label="Filter by category">
        <a class="<?= $category === "" ? "active" : "" ?>" href="index.php?action=community">All</a>
        <?php foreach ($categories as $key => $label): ?>
            <a class="<?= $category === $key ? "active" : "" ?>" href="index.php?action=community&amp;category=<?= urlencode($key) ?>"><?= cm_e($label) ?></a>
        <?php endforeach; ?>
    </nav>

    <?php if (!$posts): ?>
        <div class="empty-state">
            <h3>No posts yet</h3>
            <p><?= $category === "" ? "Be the first to start a conversation." : "Nothing in this category yet. Write the first post." ?></p>
        </div>
    <?php endif; ?>

    <?php foreach ($posts as $post):
        $postId = (int)$post["post_id"];
        $comments = $commentsByPost[$postId] ?? [];
        $isOwner = (int)$post["user_id"] === $currentUserId;
    ?>
        <article class="post-card" id="post-<?= $postId ?>">
            <header class="post-head">
                <?= cm_avatar($post) ?>
                <div class="post-author">
                    <strong><?= cm_e($post["name"]) ?></strong>
                    <span class="role"><?= cm_e(ucfirst($post["role"])) ?></span>
                    <small>
                        <?= cm_e(cm_time_ago($post["age_seconds"], $post["created_at"])) ?>
                        <?php if (!empty($post["updated_at"])): ?>· edited<?php endif; ?>
                    </small>
                </div>
                <span class="post-category"><?= cm_e($categories[$post["category"]] ?? ucfirst($post["category"])) ?></span>
            </header>

            <?php if ($post["pinned"]): ?><span class="featured-label">✦ Featured by AGREA</span><?php endif; ?><p class="post-content"><?= nl2br(cm_e($post["content"])) ?></p>

            <?php if ($post["video_mime"] === "image/gif"): ?><img class="farm-video community-gif" loading="lazy" src="index.php?action=communityVideo&amp;id=<?= $postId ?>" alt="Animated community attachment"><?php elseif ($post["video_mime"]): ?><video class="farm-video" controls playsinline preload="metadata" src="index.php?action=communityVideo&amp;id=<?= $postId ?>"></video><?php endif; ?><div class="post-actions">
                <form method="post" action="index.php?action=toggleLike">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_id" value="<?= $postId ?>">
                    <input type="hidden" name="category_filter" value="<?= cm_e($category) ?>">
                    <input type="hidden" name="page" value="<?= (int)$page ?>">
                    <button type="submit" class="like-btn<?= $post["liked"] ? " liked" : "" ?>" aria-pressed="<?= $post["liked"] ? "true" : "false" ?>">
                        <svg viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                        <span><?= (int)$post["like_count"] ?></span>
                    </button>
                </form>

                <?php if ($isOwner || $isAdmin): ?>
                    <div class="post-owner-actions">
                        <?php if ($isOwner): ?>
                            <a href="index.php?action=editPost&amp;id=<?= $postId ?>">Edit</a>
                        <?php endif; ?>
                        <form method="post" action="index.php?action=deletePost" onsubmit="return confirm('Delete this post and its comments?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="post_id" value="<?= $postId ?>">
                            <input type="hidden" name="category_filter" value="<?= cm_e($category) ?>">
                            <input type="hidden" name="page" value="<?= (int)$page ?>">
                            <button class="text-danger" type="submit">Delete</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>

            <details class="post-comments"<?= $openPost === $postId ? " open" : "" ?>>
                <summary>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    <?= (int)$post["comment_count"] ?> comment<?= (int)$post["comment_count"] === 1 ? "" : "s" ?>
                </summary>

                <?php foreach ($comments as $comment):
                    $canDeleteComment = $isAdmin
                        || (int)$comment["user_id"] === $currentUserId
                        || $isOwner;
                ?>
                    <div class="comment">
                        <?= cm_avatar($comment, "avatar avatar-sm") ?>
                        <div class="comment-body">
                            <div class="comment-meta">
                                <strong><?= cm_e($comment["name"]) ?></strong>
                                <span class="role"><?= cm_e(ucfirst($comment["role"])) ?></span>
                                <small><?= cm_e(cm_time_ago($comment["age_seconds"], $comment["created_at"])) ?></small>
                            </div>
                            <p><?= nl2br(cm_e($comment["content"])) ?></p>
                        </div>
                        <?php if ($canDeleteComment): ?>
                            <form method="post" action="index.php?action=deleteComment" onsubmit="return confirm('Delete this comment?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="comment_id" value="<?= (int)$comment["comment_id"] ?>">
                                <input type="hidden" name="category_filter" value="<?= cm_e($category) ?>">
                                <input type="hidden" name="page" value="<?= (int)$page ?>">
                                <button class="text-danger" type="submit" aria-label="Delete comment">Delete</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <form class="comment-form" method="post" action="index.php?action=addComment">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_id" value="<?= $postId ?>">
                    <input type="hidden" name="category_filter" value="<?= cm_e($category) ?>">
                    <input type="hidden" name="page" value="<?= (int)$page ?>">
                    <input type="text" name="content" maxlength="1000" required placeholder="Write a comment…" aria-label="Write a comment">
                    <button class="primary-action" type="submit">Send</button>
                </form>
            </details>
        </article>
    <?php endforeach; ?>

    <?php if ($pages > 1):
        $base = "index.php?action=community" . ($category !== "" ? "&amp;category=" . urlencode($category) : "");
    ?>
        <nav class="pagination" aria-label="Pages">
            <?php if ($page > 1): ?><a href="<?= $base ?>&amp;page=<?= $page - 1 ?>">← Newer</a><?php endif; ?>
            <span>Page <?= (int)$page ?> of <?= (int)$pages ?></span>
            <?php if ($page < $pages): ?><a href="<?= $base ?>&amp;page=<?= $page + 1 ?>">Older →</a><?php endif; ?>
        </nav>
    <?php endif; ?>

    <?php endif; ?>
</main>
<script src="assets/js/app.js" defer></script>
<script src="assets/js/community.js" defer></script>
</body>
</html>

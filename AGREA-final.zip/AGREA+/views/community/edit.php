<?php require_once __DIR__ . "/../shared/community_helpers.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit post - AGREA</title>
    <link rel="icon" href="assets/images/logo/AGREA.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php require __DIR__ . "/../shared/sidebar.php"; ?>
<main class="admin-container community-page">
    <p><a href="index.php?action=community">← Back to the community</a></p>
    <h2>Edit your post</h2>

    <?php if ($error): ?><div class="error" role="alert"><?= cm_e($error) ?></div><?php endif; ?>

    <form class="post-composer post-edit" method="post" action="index.php?action=editPost&amp;id=<?= (int)$post["post_id"] ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="post_id" value="<?= (int)$post["post_id"] ?>">
        <div class="composer-body">
            <textarea name="content" rows="6" maxlength="<?= (int)$postMax ?>" required data-counter="composer-count"><?= cm_e($post["content"]) ?></textarea>
            <div class="composer-bar">
                <select name="category" aria-label="Category">
                    <?php foreach ($categories as $key => $label): ?>
                        <option value="<?= cm_e($key) ?>"<?= $post["category"] === $key ? " selected" : "" ?>><?= cm_e($label) ?></option>
                    <?php endforeach; ?>
                </select>
                <span class="char-count"><span id="composer-count">0</span>/<?= (int)$postMax ?></span>
                <button class="primary-action" type="submit">Save changes</button>
            </div>
        </div>
    </form>
</main>
<script src="assets/js/app.js" defer></script>
<script src="assets/js/community.js" defer></script>
</body>
</html>

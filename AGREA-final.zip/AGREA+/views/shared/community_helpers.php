<?php

if (!function_exists("cm_e")) {
    function cm_e($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
    }
}

// "5 min ago" style label, computed from the age in seconds given by MySQL
if (!function_exists("cm_time_ago")) {
    function cm_time_ago($seconds, $createdAt): string
    {
        $s = max(0, (int)$seconds);
        if ($s < 60) return "just now";
        if ($s < 3600) return floor($s / 60) . " min ago";
        if ($s < 86400) return floor($s / 3600) . " h ago";
        if ($s < 7 * 86400) return floor($s / 86400) . " d ago";
        return date("M j, Y", strtotime((string)$createdAt));
    }
}

if (!function_exists("cm_avatar")) {
    function cm_avatar(array $row, string $class = "avatar"): string
    {
        if (!empty($row["profile_picture"])) {
            return '<span class="' . $class . '"><img src="' . cm_e($row["profile_picture"])
                . '" alt=""></span>';
        }
        $initial = strtoupper(substr((string)($row["name"] ?? "?"), 0, 1));
        return '<span class="' . $class . '">' . cm_e($initial) . '</span>';
    }
}

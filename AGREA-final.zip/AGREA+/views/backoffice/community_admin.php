<?php require_once __DIR__ . "/../shared/community_helpers.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Community moderation - AGREA</title>
    <link rel="icon" href="assets/images/logo/AGREA.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php require __DIR__ . "/../shared/sidebar.php"; ?>
<main class="admin-container community-page">
    <div class="dashboard-heading">
        <div>
            <h2>Community moderation</h2>
            <p>Review and remove posts and comments published by members.</p>
        </div>
        <span class="role-badge">Administrator</span>
    </div>

    <?php if ($flash): ?>
        <div class="<?= $flash[0] === "success" ? "success" : "error" ?>" role="status"><?= cm_e($flash[1]) ?></div>
    <?php endif; ?>

    <?php if (!$tablesReady): ?>
        <div class="error" role="status">Apply <code>database/migrations/2026_11_24_create_community_tables.sql</code> to enable the community.</div>
    <?php else: ?>

    <section class="admin-stats" aria-label="Community totals">
        <div class="admin-stat-card"><h3><?= (int)$stats["posts"] ?></h3><p>Posts</p></div>
        <div class="admin-stat-card"><h3><?= (int)$stats["comments"] ?></h3><p>Comments</p></div>
        <div class="admin-stat-card"><h3><?= (int)$stats["likes"] ?></h3><p>Likes</p></div>
        <div class="admin-stat-card"><h3><?= (int)$stats["authors"] ?></h3><p>Active authors</p></div>
    </section>

    <section class="dashboard-section">
        <h2>Latest posts</h2>
        <?php if (!$posts): ?>
            <div class="empty-state"><h3>No posts yet</h3></div>
        <?php else: ?>
            <div class="table-scroll">
            <table class="moderation-table">
                <thead><tr><th>Author</th><th>Post</th><th>Category</th><th>Likes</th><th>Comments</th><th>Date</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($posts as $p): ?>
                    <tr>
                        <td><?= cm_e($p["name"]) ?></td>
                        <td class="excerpt"><?= cm_e(mb_strimwidth($p["content"], 0, 110, "…", "UTF-8")) ?><?php if ($p["video_mime"] === "image/gif"): ?><img class="admin-video" src="index.php?action=communityVideo&amp;id=<?= (int)$p["post_id"] ?>" alt="GIF attachment"><?php elseif ($p["video_mime"]): ?><video class="admin-video" controls preload="none" src="index.php?action=communityVideo&amp;id=<?= (int)$p["post_id"] ?>"></video><?php endif; ?></td>
                        <td><?= cm_e($categories[$p["category"]] ?? $p["category"]) ?></td>
                        <td><?= (int)$p["like_count"] ?></td>
                        <td><?= (int)$p["comment_count"] ?></td>
                        <td><?= cm_e(date("Y-m-d", strtotime($p["created_at"]))) ?></td>
                        <td><form method="post" action="index.php?action=pinPost"><?= csrf_field() ?><input type="hidden" name="post_id" value="<?= (int)$p["post_id"] ?>"><button type="submit" class="primary-action"><?= $p["pinned"] ? "Unpin" : "Feature" ?></button></form>
                            <form method="post" action="index.php?action=deletePost" onsubmit="return confirm('Delete this post and its comments?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="post_id" value="<?= (int)$p["post_id"] ?>">
                                <input type="hidden" name="from" value="admin">
                                <button class="text-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </section>

    <section class="dashboard-section">
        <h2>Latest comments</h2>
        <?php if (!$comments): ?>
            <div class="empty-state"><h3>No comments yet</h3></div>
        <?php else: ?>
            <div class="table-scroll">
            <table class="moderation-table">
                <thead><tr><th>Author</th><th>Comment</th><th>On post</th><th>Date</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($comments as $c): ?>
                    <tr>
                        <td><?= cm_e($c["name"]) ?></td>
                        <td class="excerpt"><?= cm_e(mb_strimwidth($c["content"], 0, 110, "…", "UTF-8")) ?></td>
                        <td><a href="index.php?action=community&amp;open=<?= (int)$c["post_id"] ?>#post-<?= (int)$c["post_id"] ?>">#<?= (int)$c["post_id"] ?></a></td>
                        <td><?= cm_e(date("Y-m-d", strtotime($c["created_at"]))) ?></td>
                        <td>
                            <form method="post" action="index.php?action=deleteComment" onsubmit="return confirm('Delete this comment?')">
                                <?= csrf_field() ?>
                                <input type="hidden" name="comment_id" value="<?= (int)$c["comment_id"] ?>">
                                <input type="hidden" name="from" value="admin">
                                <button class="text-danger" type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </section>

    <?php endif; ?>
</main>
<script src="assets/js/app.js" defer></script>
</body>
</html>

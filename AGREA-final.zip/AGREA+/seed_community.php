<?php
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
require __DIR__.'/config/database.php';
(new Database())->connect();
echo "Automatic setup and demo seed completed (once per database).\n";
